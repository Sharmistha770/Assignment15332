package controller_70;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao_70.Dao_70_Friends;
import model_70.Model_70_Query;


/**
 * Servlet implementation class C_10_Add
 */
@WebServlet("/Controller_70_Add")
public class Controller_70_Add extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Controller_70_Add() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			Model_70_Query add = new Model_70_Query();
			Dao_70_Friends friends = new Dao_70_Friends();
			
			String name = request.getParameter("name");
			String email = request.getParameter("email");
			String age = request.getParameter("age");
			String color = request.getParameter("favoriteColor");

			// Execute the read and get the data in the table variable
			friends.AddFriend(name, email, age, color);

			String url = "/Controller_70_Read";

			RequestDispatcher dispatcher = request.getRequestDispatcher(url);
			dispatcher.forward(request, response);
		} 
		catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
