package controller_70;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao_70.Dao_70_Friends;


@WebServlet("/Controller_70_Delete")
public class Controller_70_Delete extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Controller_70_Delete() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String id = request.getParameter("id");

		int id2 = Integer.parseInt(id);
		
		try {
			Dao_70_Friends dbFriend = new Dao_70_Friends();
			Controller_70_Read create = new Controller_70_Read();
			
			dbFriend.deleteFriend(id2);
			
			create.doGet(request, response);
			

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
