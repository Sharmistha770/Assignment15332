package controller_70;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import dao_70.Dao_70_Friends;
import model_70.Model_70_Query;


@WebServlet("/Controller_70_Read")
public class Controller_70_Read extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Model_70_Query friends;
    public Controller_70_Read() {
        super();
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			Dao_70_Friends df = new Dao_70_Friends();
			friends = new Model_70_Query();
			
			String table = "";
			
			table = df.ShowFriend(friends);
			
			request.setAttribute("table", table);
			
			String url = "/view_70_read.jsp";
			
			RequestDispatcher dispatcher = request.getRequestDispatcher(url);
			dispatcher.forward(request, response);

		}catch(Exception ex) {
			ex.printStackTrace();
		}
}
	

}
