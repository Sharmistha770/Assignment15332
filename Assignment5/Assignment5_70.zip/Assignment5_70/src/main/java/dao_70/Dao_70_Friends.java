package dao_70;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import model_70.Model_70_Query;



public class Dao_70_Friends {
	
	Connection connection;
	
	
	PreparedStatement preparedStatement;
	ResultSet resultSet = null;
	//create operation in CRUD
	public int AddFriend(String name, String email, String age, String color) throws ClassNotFoundException {
		
		int result = 0;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/w11_sharmistha";
			String username="root";
			String password = "";
			connection = DriverManager.getConnection(url, username, password);
							
			String query = "INSERT INTO friends(name, email, age, favoriteColor) VALUES(?,?,?,?)";
			
			preparedStatement = connection.prepareStatement(query);
			
			
			preparedStatement.setString(1, name);
			preparedStatement.setString(2, email);
			preparedStatement.setInt(3, Integer.parseInt(age));
			preparedStatement.setString(4, color);
			
			result = preparedStatement.executeUpdate();				
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return result;		
	}
	
	public String ShowFriend(Model_70_Query show) throws ClassNotFoundException {
		
		String table = "";
		String query = "select * from friends";
			
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/w11_sharmistha";
			String username="root";
			String password = "";
			connection = DriverManager.getConnection(url, username, password);

			preparedStatement = connection.prepareStatement(query);
			
			this.resultSet = preparedStatement.executeQuery();	
			
			table += "<table border=1>";
			table += "<tr><th>ID</th><th>Age</th><th>Name</th><th>Email Address</th><th>Color</th><th>Delete</th></tr>";

			while (this.resultSet.next()) {
				int id = this.resultSet.getInt("id");
				String name = this.resultSet.getString("name");
				String email = this.resultSet.getString("email");
				int age = this.resultSet.getInt("age");
				String favoriteColor = this.resultSet.getString("favoriteColor");

				Model_70_Query friend = new Model_70_Query(id, name, email, age, favoriteColor);
				table += "<tr>";
				table += "<td>";
				table += friend.getId();
				table += "</td>";
				table += "<td>";
				table += friend.getName();
				table += "</td>";
				table += "<td>";
				table += friend.getEmail();
				table += "</td>";
				table += "<td>";
				table += friend.getAge();
				table += "</td>";
				table += "<td>";
				table += friend.getFavoriteColor();
				table += "</td>";
				table += "<td>";
				table += "<a href='Controller_70_Delete?id=" + friend.getId() + "'>Delete</a>";
				table += "</td>";
				table += "</tr>";
							
			}	
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return table;			
	}
	
	public void deleteFriend (int id) throws ClassNotFoundException {
		
		String query = "DELETE FROM friends WHERE id=?";
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/w11_sharmistha";
			String username="root";
			String password = "";
			connection = DriverManager.getConnection(url, username, password);
					
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, id);
			
			preparedStatement.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
}
