package model_70;

public class Model_70_Query {

	private int id;
	private String name;
	private String email;
	private int age;
	private String favoriteColor;

	public Model_70_Query() {

		this.name = "";
		this.email = "";
		this.age = 0;
		this.favoriteColor = "";
	}

	public Model_70_Query(int id, String name, String email, int age, String favoriteColor) {

		this.id = id;
		this.name = name;
		this.email = email;
		this.age = age;
		this.favoriteColor = favoriteColor;
	}

	public Model_70_Query(String name, String email, int age, String favoriteColor) {

		this.name = name;
		this.email = email;
		this.age = age;
		this.favoriteColor = favoriteColor;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getFavoriteColor() {
		return favoriteColor;
	}

	public void setFavoriteColor(String favoriteColor) {
		this.favoriteColor = favoriteColor;
	}

	@Override
	public String toString() {

		return "Friends - [friendID=" + id + ", age=" + age + ", friendName=" + name + ", emailAddress=" + email
				+ ", favoriteColor=" + favoriteColor + "]";
	}
}
